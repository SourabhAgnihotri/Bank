import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CountryStateService {

  countryList = [
    { id: 1, name: "India" },
    { id:2, name: "USA"}
  ]  
  stateList = [
    { id: 1, name: "Gujarat" },
    { id: 1, name: "Maharastra" },
    { id: 1, name: "Rajasthan" },
    { id: 2, name: "Alaska" },
    { id: 2, name: "Arizona" },
    { id: 2, name: "Alabama" },
  ]

  get country(){
    return this.countryList;
  }

  get state(){
    return this.stateList;
  }
  
  constructor() {
    
   }
}
