import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthGaurdService } from '../auth-gaurd.service';
import { LoginService } from '../model/login.service';
import { RegistrationService } from '../registeration/registration.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

user:{ username: String; pass: any; gender: string; } | undefined
  flag:any
  msg:any
  valid:any
  
  genders:any=['male','female']
  constructor(private router:Router,private route:ActivatedRoute,private authService:AuthGaurdService,
    private loginService:LoginService,private regisService:RegistrationService) { }

  ngOnInit(): void {
  }

  
  auth(form1:NgForm)
  {
    // console.log(this.loginService.getCustomerId())
    // if(((this.loginService.getCustomerId()===form.controls['email'].value) || 
    // (this.loginService.getUsername()===form.controls['email'].value)) &&
    // (this.loginService.getPassword()===form.controls['password'].value))
    // {
    //    this.authService.auth=true;
    // }
    // else{
    //   this.authService.auth=true;  
    // }
    console.log(form1.value.userData.email);
    if(localStorage.getItem('customerId')==form1.value.userData.email &&
    localStorage.getItem('password')==form1.value.userData.password){
      this.authService.auth=true;
      this.router.navigate(['/loan'])
      this.valid=true

    }
   else{
     this.valid=false
     this.msg="Invalid Credentials"
   }
  }
}
