import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RegistrationService {

  customerId:any
  data!: { username: any; password: any; }; 
  constructor(private http:HttpClient) {
   
   }

  regis(data:any){
    this.http.post("assets/data.json",data);
  }

  setCustomerId(customerId:any){
    this.customerId=customerId;
  }

  getCustomrId(){
    return this.customerId;
  }
}
