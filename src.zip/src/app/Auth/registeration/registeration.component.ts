import { DatePipe, formatDate } from '@angular/common';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { CountryStateService } from '../country-state.service';
import { Country } from '../model/country.model';
import { State } from '../model/state.model';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { NgForm } from '@angular/forms';
import { LoginService } from '../model/login.service';
import { RegistrationService } from './registration.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registeration',
  templateUrl: './registeration.component.html',
  styleUrls: ['./registeration.component.css']
})
export class RegisterationComponent implements OnInit {
 
  selectedCountryId : any;
  country : Country[] = [];
  state :State[]=[];
  stateList:string[]=[];
  genders:any=['Male','Female'];
  maritalStatus=['Single','Married'];
  citizenStatus:any
  regisDate = new Date()
  today :any
  minDate: Date
  maxDate:Date
  initialAmount:any
  accType:any
  dateOfBirth:any
  @ViewChild('f') form:NgForm | undefined
  guardianTypes:['father', 'husband'] | undefined 
  @ViewChild('guardianType') gt:ElementRef | undefined
  customerId:any
  c:any
  
   

   

 

  constructor(private regService : CountryStateService,private datePipe:DatePipe,private loginService:LoginService,
    private regisServices:RegistrationService,private router:Router ) {
    for (let a of this.regService.country) {
      let countryObj = new Country(a.id,a.name);
      this.country.push(countryObj);

      
    }

    for (let a of this.regService.state) {
      let stateObj = new State(a.id,a.name);
      this.state.push(stateObj);
    }

    
    const currentYear = new Date().getFullYear();
    const currentMonth=new Date().getMonth();
    const currentDay=new Date().getDate();
    this.minDate = new Date(currentYear - 18,currentMonth,currentDay);
    this.maxDate = new Date(currentYear - 96,currentMonth,currentDay);
    this.today = datePipe.transform(this.regisDate,"dd-MM-yyyy")
    this.accType="Saving"
   }

  ngOnInit(): void {
   
    
  }
  sendId()
  {
    this.stateList = [];
      for(let s of this.state){
        if(s.id== this.selectedCountryId)
        {
          this.stateList.push(s.name)
        }
      }


  }

  accTypeCheck(){
    if(this.accType=="Saving")
    {
      this.initialAmount=5000
    }
    else{
      this.initialAmount=""
    }
  }
  
  citizenStatusCheck(){
    let date=this.dateOfBirth.getFullYear();
    let now=this.regisDate.getFullYear();
    let age=now-date
    if(age<18)
    {
        this.citizenStatus="Minor";
    }
    else if(age>=18 && age<=60)
    {
      this.citizenStatus="Normal"
    }
    else{
      this.citizenStatus="Senior"
    }
  }
  
  reset(){
    this.form?.reset();
  }

  getCustomerId(){
    
      this.customerId="R"+ Math.random().toString(36).substr(2, 3);
      this.regisServices.setCustomerId(this.customerId);
    
  }
  
  test(f:NgForm){
      this.getCustomerId()
     localStorage.setItem('customerId',this.regisServices.getCustomrId());
     localStorage.setItem('password',f.controls['password'].value);
    // this.loginService.setUsername(localStorage.getItem('username'));
    // this.loginService.setPassword(localStorage.getItem('password'));
    // this.loginService.setCustomerId(localStorage.getItem('username'));
    // console.log(localStorage.getItem('username'));
    console.log(this.regisServices.getCustomrId())
    console.log(f.controls['password'].value)
    alert("Registration Successful")
    this.router.navigate(['/login'])


    
    
    
    
  }

}
