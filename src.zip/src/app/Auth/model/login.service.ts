import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService{
    username:any="";
    password:any ="";
    customerId:any="";

    
    public getUsername() : string {
        return this.username;

    }

    public getPassword() : string {
        return this.password;
    }

    public getCustomerId() : string {
        return this.customerId
    }

    public setUsername(username:any) {
         this.username=username
    }

    public setPassword(password:any) {
        this.password=password
    }

    public setCustomerId(customerId:any) {
        this.customerId=customerId
    }
    

}