import { NgModule } from 
    '@angular/core';
import { BrowserModule } from 
    '@angular/platform-browser';
import { RouterModule, Routes } from 
    '@angular/router';
import { AppComponent } from './app.component';
import { LoginComponent } from 
    './Auth/login/login.component';
import { AuthGaurdService } from 
    './Auth/auth-gaurd.service';
import { FormsModule } from '@angular/forms';
import { RegisterationComponent } from
     './Auth/registeration/registeration.component';
import { DatePipe } from '@angular/common';
import { BrowserAnimationsModule } from 
      '@angular/platform-browser/animations';
import { MatButtonModule } from 
    '@angular/material/button';
import { MatButtonToggleModule } from 
    '@angular/material/button-toggle';
import { MatDatepickerModule } from 
    '@angular/material/datepicker';
import { MatInputModule } from 
    '@angular/material/input';
import { MatFormFieldModule } from 
    '@angular/material/form-field';
import { MatNativeDateModule } from 
    '@angular/material/core';
import { LoanComponent } from 
    './Loan/loan/loan.component';
import { EducationLoanComponent } from 
    './Loan/loan/education-loan/education-loan.component';
import { PersonalHomeLoanComponent } from 
    './Loan/loan/personal-home-loan/personal-home-loan.component';
import { HeaderComponent } from 
    './Header/header/header.component';
import { PageNotFoundComponent } from 
    './Error/page-not-found/page-not-found.component';
import { HttpClientModule } from '@angular/common/http';

const appRoutes:Routes=[
  {path:"login",component:LoginComponent},
  {path:'',redirectTo:"/login",pathMatch:'full'},
  {path:"registration",component:RegisterationComponent},
  {path:"loan",component:LoanComponent,canActivate:[AuthGaurdService]},
    // ,children:[{path:"educationloan",component:EducationLoanComponent}],
  {path:"educationloan",component:EducationLoanComponent,canActivate:[AuthGaurdService]},
  {path:"personal-home-loan",component:PersonalHomeLoanComponent,canActivate:[AuthGaurdService]},
  {path:"**",component:PageNotFoundComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterationComponent,
    LoanComponent,
    EducationLoanComponent,
    PersonalHomeLoanComponent,
    HeaderComponent,
    PageNotFoundComponent,
    
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(appRoutes),
    FormsModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatDatepickerModule,
    MatInputModule,
    MatFormFieldModule,
    MatNativeDateModule,
    BrowserAnimationsModule,
    HttpClientModule

  ],
  providers: [AuthGaurdService,DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
