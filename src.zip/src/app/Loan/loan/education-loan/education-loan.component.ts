import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-education-loan',
  templateUrl: './education-loan.component.html',
  styleUrls: ['./education-loan.component.css']
})
export class EducationLoanComponent implements OnInit {

  
  constructor() { }

  ngOnInit(): void {
  }

}
