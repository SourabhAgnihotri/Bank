import { DatePipe } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-loan',
  templateUrl: './loan.component.html',
  styleUrls: ['./loan.component.css']
})
export class LoanComponent implements OnInit {

  today=new Date();
  loanAD:any;
  loanTypes:any;
  intRate:any;
  data:any
   loanID: any


  constructor(private datePipe:DatePipe,private router:Router,private route:ActivatedRoute) { 
    this.loanTypes="Education Loan"
    this.interestRate();
    

  }

  ngOnInit(): void {
    this.loanAD = this.datePipe.transform(this.today,"dd-MM-yyyy")
    const currentYear = new Date().getFullYear();
    const currentMonth=new Date().getMonth();
    const currentDay=new Date().getDate();
    this.loanID=new Date(currentYear,currentMonth,currentDay+14);
    this.loanID=this.datePipe.transform(this.loanID,"dd-MM-yyyy")
  }

  interestRate()
  {
      if(this.loanTypes=="Education Loan")
      {
          this.intRate=12
      }
      else if(this.loanTypes=="Personal/Home Loan")
      {
          this.intRate=8
      }
  }

  submitData(form:NgForm){
      //this.data=form.value.userData;.
      if(this.loanTypes=="Education Loan")
      {
        this.router.navigate(["/educationloan"]);
      }
      else if("Personal/Home Loan")
      {
        this.router.navigate(["/personal-home-loan"]);
      }
      
  }

}
