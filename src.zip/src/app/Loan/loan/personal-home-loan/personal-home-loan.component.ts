import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-loan',
  templateUrl: './personal-home-loan.component.html',
  styleUrls: ['./personal-home-loan.component.css']
})
export class PersonalHomeLoanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
